# # program 1
a = 1
z = 10
while a<=11 and z>=1 :
    print(a, end=" ")
    a=a+1
    print(z,end=" ")
    z=z-1

# # program 2
awal = int(input("masukkan saldo awal\t:"))
sisa = awal
while (True):
    pengeluaran = int(input("masukkan pengeluaran (-1 untuk keluar):"))
    if pengeluaran== -1 :
        print("sisa saldo :",sisa)
        break
    sisa = sisa - pengeluaran
    
    if sisa < 0 :
        print("saldo tidak cukup.")
        print("sisa saldo", sisa+pengeluaran)
        
# program 3
x = 1
while x <= 10 :
    print("7 X", x ,"=", 7*x)
    x = x + 1
    
# # program 4
data = int(input("masukkan banyak data :"))
jumlah_data = 0

for i in range(0,data) :
    data_input = int(input("masukkan jumlah data :"))
    jumlah_data += data_input
    if data_input== data :
        break

hasil = jumlah_data/data
print(hasil)

# program 5
var_nilai = 10
var_i = 1 

for var_nilai in range(0,10) :
    print("perulangan pertama, ke", var_nilai)
    for var_i in range(1,3) :
        print("perulangan ke",var_nilai, var_i)
print("var_nilai =", int(var_nilai)+1," = 10. Bernilai false.")
# program 6
var_nilai = 0
var_i = 1 

while (var_nilai < 10) :
    print("Perulangan pertama Ke ",var_nilai)
    while(var_i < 3) :
        print(" Perulangan ke ", var_nilai,", ",var_i)
        var_i +=1
#diluar perulangan var_i
        var_i = 1
        var_nilai +=1
        break
#diluar_perulangan var_nilai
print("var_nilai = ",int(var_nilai)," = 10. Bernilai False") 
# program 7
var_nilai = 0
var_i = 1 

for var_nilai in range (0,10) :
    print("Perulangan pertama Ke ",var_nilai)
    while(var_i < 3) :
        print(" Perulangan ke ", var_nilai,", ",var_i)
        var_i +=1
    var_i = 1
#diluar_perulangan var_nilai
print("var_nilai = ",int(var_nilai)+1," = 10. Bernilai False")
